<script>
  import Nav from "./lib/components/Nav.svelte";
  import Hero from "./lib/components/Hero.svelte";
</script>

<main>
  <Nav />
  <Hero />
</main>

<style>
</style>
